#!/bin/bash
echo

app_name="CI360 SAS CZ nbx AGENT"
running=0

#test if start.pid exists and PID  is running
if test -f "start.pid"; 
then
	if ps -p `cat start.pid` > /dev/null 
	then
		running=1
		echo "$app_name is already running !"
	fi
fi



if [ "$running" == "0" ]
then
	#start application
	echo Starting $app_name

	java -Dlogback.configurationFile=logback.xml  -Djavax.net.ssl.trustStore=/appl/sas/viya/home/SASSecurityCertificateFramework/java/cacerts -Djavax.net.ssl.trustStorePassword=changeit -DconfigFile=app.config  -jar agent-nbx.jar 2>&1 &  echo $! > start.pid
fi

echo
