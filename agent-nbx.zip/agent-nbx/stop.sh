kill -15 `cat start.pid`
rm start.pid